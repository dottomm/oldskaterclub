<?php
        $form = array(
            'key'                       => '${filename}',
            'AWSAccessKeyId'            => 'AKIAIUUWXSJMKHC75P4A',
            'AWSSecretKey'				=> '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',
            'acl'                       => 'public-read',
            'success_action_redirect'   => 'http://www.dottomm.com/s3upload/thankyou.html',
        );


        $form['policy'] = '{
            {"expiration": "20018-01-01T00:00:00Z",
  "conditions": [ 
    {"bucket": "tomdropbox"}, 
    ["starts-with", "$key", "uploads/"],
    {"acl": "public-read"},
    {"success_action_redirect": "http://localhost/"},
    ["starts-with", "$Content-Type", ""],
    ["content-length-range", 0, 1048576]
  ]
}';

    $form['policy_encoded'] = base64_encode($form['policy']);
    
    $form['signature'] = base64_encode(hash_hmac( 'sha1', base64_encode(utf8_encode($form['policy'])), 'Dx1ECvBHbdEWv78XoN5cs7HoUqDgb+csewZyojtK'));

?>


<form action="https://tomdropbox.s3.amazonaws.com/" method="post" enctype="multipart/form-data">
      <input type="hidden" name="key" value="<?php echo $form['key'] ?>">
      <input type="hidden" name="AWSAccessKeyId" value="<?php echo $form['AWSAccessKeyId'] ?>"> 
      <input type="hidden" name="acl" value="<?php echo $form['acl'] ?>">
      <input type="hidden" name="success_action_redirect" value="<?php echo $form['success_action_redirect'] ?>">
      <input type="hidden" name="policy" value="<?php echo $form['policy'] ?>">
      <input type="hidden" name="signature" value="<?php echo $form['signature'] ?>">
       

      File to upload to S3:
      <input name="file" type="file">
      <br>
      <input type="submit" value="Upload File to S3">
</form>