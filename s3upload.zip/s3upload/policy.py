{"expiration": "2009-01-01T00:00:00Z",
  "conditions": [ 
    {"bucket": "tomdropbox"}, 
    ["starts-with", "$key", "uploads/"],
    {"acl": "private"},
    {"success_action_redirect": "http://localhost/s3upload/thankyou.html"},
    ["starts-with", "$Content-Type", ""],
    ["content-length-range", 0, 1048576]
  ]
}