<?php
// Bucket Name
$bucket="tomdropbox";
if (!class_exists('S3'))require_once('S3.php');
			
//AWS access info
if (!defined('awsAccessKey')) define('awsAccessKey', 'AKIAIUUWXSJMKHC75P4A');
if (!defined('awsSecretKey')) define('awsSecretKey', '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');
			
//instantiate the class
$s3 = new S3(awsAccessKey, awsSecretKey);

$s3->putBucket($bucket, S3::ACL_PUBLIC_READ);

?>